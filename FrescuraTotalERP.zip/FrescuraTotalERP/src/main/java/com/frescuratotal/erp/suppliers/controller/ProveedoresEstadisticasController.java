package com.frescuratotal.erp.suppliers.controller;

import com.frescuratotal.erp.common.LogUtils;
import com.frescuratotal.erp.suppliers.model.ProveedoresEstadisticas;
import com.frescuratotal.erp.suppliers.model.ProveedoresEstadisticasDAO;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public class ProveedoresEstadisticasController {

    private ProveedoresEstadisticasDAO proveedoresEstadisticasDAO = new ProveedoresEstadisticasDAO();

    public List<String> listarEstadisticas(){
        List<ProveedoresEstadisticas> filas;
        try {
            filas = proveedoresEstadisticasDAO.listarEstadisticas();
            return armarReporte(filas);
        }catch (SQLException e){
            LogUtils.error("Error al listar estadisticas de proveedores.", e);
            return new ArrayList<>();
        }
    }


    public List<String> armarReporte(List<ProveedoresEstadisticas> filas) {
        List<String> reporte = new ArrayList<>();

        if (filas.isEmpty()) {
            reporte.add("No existen datos suficientes para generar estadísticas comerciales.");
            return reporte;
        }

        reporte.add("===== ESTADISTICAS COMERCIALES =====");

        Optional<Map.Entry<String, Double>> top = proveedorConMasVentas(filas);
        if (top.isPresent()) {
            reporte.add("Proveedor con mayor volumen vendido: " + top.get().getKey()
                    + " - " + formatearCantidad(top.get().getValue()) + " unidades");
        } else {
            reporte.add("Proveedor con mayor volumen vendido: no hay ventas confirmadas");
        }


        return reporte;
    }

    public Optional<Map.Entry<String, Double>> proveedorConMasVentas(List<ProveedoresEstadisticas> filas) {
        return filas.stream()
                .collect(Collectors.groupingBy(
                        ProveedoresEstadisticas::getNombreProveedor,
                        Collectors.summingDouble(ProveedoresEstadisticas::getCantidadInicial)))
                .entrySet().stream()
                .max(Map.Entry.comparingByValue());
    }

    public Optional<Map.Entry<String, Double>> proveedorConVencidos(List<ProveedoresEstadisticas> filas) {
        return filas.stream()
                .filter(p -> p.getEstadoLote().equalsIgnoreCase("Vencida"))
                .collect(Collectors.groupingBy(
                        ProveedoresEstadisticas::getNombreProveedor,
                        Collectors.summingDouble(ProveedoresEstadisticas::getCantidadInicial)))
                .entrySet().stream()
                .max(Map.Entry.comparingByValue());
    }

    private String formatearCantidad(double cantidad) {
        if (cantidad == Math.rint(cantidad)) {
            return String.valueOf((long) cantidad);
        }
        return String.valueOf(cantidad);
    }


}



