package com.frescuratotal.erp.suppliers.model;

import com.frescuratotal.erp.inventory.model.EstadoLote;

public class ProveedoresEstadisticas {
    private int id_lote;
    private int cantidadInicial;
    private String estadoLote;
    private int idProveedor;
    private String nombreProveedor;


    public ProveedoresEstadisticas(int id_lote, int cantidadInicial, String estadoLote, int idProveedor, String nombreProveedor) {
        this.id_lote = id_lote;
        this.cantidadInicial = cantidadInicial;
        this.estadoLote = estadoLote;
        this.idProveedor = idProveedor;
        this.nombreProveedor = nombreProveedor;
    }

    public int getId_lote() {
        return id_lote;
    }

    public void setId_lote(int id_lote) {
        this.id_lote = id_lote;
    }

    public int getCantidadInicial() {
        return cantidadInicial;
    }

    public void setCantidadInicial(int cantidadInicial) {
        this.cantidadInicial = cantidadInicial;
    }

    public String getEstadoLote() {
        return estadoLote;
    }

    public void setEstadoLote(String estadoLote) {
        this.estadoLote = estadoLote;
    }

    public int getIdProveedor() {
        return idProveedor;
    }

    public void setIdProveedor(int idProveedor) {
        this.idProveedor = idProveedor;
    }

    public String getNombreProveedor() {
        return nombreProveedor;
    }

    public void setNombreProveedor(String nombreProveedor) {
        this.nombreProveedor = nombreProveedor;
    }

    @Override
    public String toString() {
        return "ProveedoresEstadisticas{" +
                "id_lote=" + id_lote +
                ", cantidadInicial=" + cantidadInicial +
                ", estadoLote=" + estadoLote +
                ", idProveedor=" + idProveedor +
                ", nombreProveedor=" + nombreProveedor +
                '}';
    }
}

