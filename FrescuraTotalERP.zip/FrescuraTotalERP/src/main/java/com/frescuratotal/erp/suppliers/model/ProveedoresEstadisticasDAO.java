package com.frescuratotal.erp.suppliers.model;

import com.frescuratotal.erp.common.DatabaseConnection;
import com.frescuratotal.erp.inventory.model.EstadoLote;
import com.frescuratotal.erp.sales.model.EstadoVenta;
import com.frescuratotal.erp.sales.model.Venta;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class ProveedoresEstadisticasDAO {

    public List<ProveedoresEstadisticas> listarEstadisticas() throws SQLException {
        List<ProveedoresEstadisticas> lista = new ArrayList<>();
        String sql = "SELECT \n" +
                "    l.id_lote,\n" +
                "    l.cantidad_inicial,\n" +
                "    e.nombre AS estado_lote,\n" +
                "    p.id_proveedor,\n" +
                "    p.nombre AS nombre_proveedor\n" +
                "FROM lotes_inventario l\n" +
                "INNER JOIN proveedores p ON l.id_proveedor = p.id_proveedor\n" +
                "INNER JOIN estados_lote e ON l.id_estado = e.id_estado;";

        try(Connection conn = DatabaseConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)){

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    ProveedoresEstadisticas p = new ProveedoresEstadisticas(
                            rs.getInt("id_lote"),
                            rs.getInt("cantidad_inicial"),
                            rs.getString("estado_lote"),
                            rs.getInt("id_proveedor"),
                            rs.getString("nombre_proveedor")
                    );
                    lista.add(p);
                }
            }
        }
        return lista;
    }



}
